import os
os.system('python server5.py')